## VandyHacksNaveTeam (Team in VandyHacks Hackathon 2018)

#### Team Members: 
> Sriharsha Singam

> Gabriel Krivian

> Kyle Jiang

> Eric Gu
